﻿namespace Auth.Api.Data
{
    public class UserRoles
    {
        public const string Admin = "Admin";
        public const string Member = "Member";
    }
}
