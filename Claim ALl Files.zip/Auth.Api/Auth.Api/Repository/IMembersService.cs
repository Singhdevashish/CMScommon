﻿using Auth.Api.Models;
using Auth.Api.Models.Register;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Auth.Api.Repository
{
    public interface IMembersService
    {
        public List<MemberRegister> GetNewRegistrations();

        public Task<Response> ApproveRegistration(string memberId, string registrationStatus);

        public List<MemberRegister> GetMembers();

        public MemberRegister GetMemberById(string memberId);
    }
}
