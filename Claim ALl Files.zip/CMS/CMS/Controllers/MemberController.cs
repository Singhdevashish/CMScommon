﻿using CMS.Models;
using CMS.Models.Services;
using CMS.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class MemberController : Controller
    {

        private readonly ClaimService claim;
        private readonly PolicyService policyService;
        private readonly UserService userService;

        public MemberController(ClaimService claim, PolicyService policyService, UserService userService)
        {
            this.claim = claim;
            this.policyService = policyService;
            this.userService = userService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Create(string memberId)
        {
            ViewBag.MemberId = memberId;
            var policy = await policyService.GetAllPolicy();
            ViewBag.PolicyListName = new SelectList(policy, "PolicyId", "PolicyName");
            return View();
        }
        // Create Raise Claim is Pending.

        [HttpPost]
        public async Task<IActionResult> Create(ClaimRequest model)
        {
            if (!ModelState.IsValid) return View(model);
           
            var IsAdded = await claim.SaveClaim(model);

            if (IsAdded == true)
                return RedirectToAction("Index");

            ModelState.AddModelError("", "Failed to add Claim");
            return View(model);
        }


        public async Task<IActionResult> Details(string claimId)
        {
            var claimDetail = await claim.GetClaimsRequestedByClaimId(claimId);
            if (claimDetail == null) return NotFound();


            var policy = await policyService.GetPolicyById(claimDetail.PolicyId);
            if (policy == null) return NotFound();

            if (policy.PolicyId == claimDetail.PolicyId)
            {
                ViewBag.PolicyId = policy.PolicyId;
                ViewBag.PolicyName = policy.PolicyName;
                ViewBag.PremiumAmount = policy.PremiumAmount;
                ViewBag.Tenure = policy.Tenure;
            }

            /*var member = await userService.GetMembersById(claimDetail.MemberId);
            if (member == null) return NotFound();

            ViewBag.MemberId = member.MemberId;
            ViewBag.Name = member.FirstName + " " + member.LastName;
            ViewBag.PhoneNumber = member.ContactNumber;
            ViewBag.Gender = member.Gender;*/

            return View(claimDetail);
        }

        public async Task<IActionResult> GetClaimsRequestedByMember(string memberId)
        {
            var request = await claim.GetClaimsRequestedByMember(memberId);
            return View(request);
        }
    }
}
