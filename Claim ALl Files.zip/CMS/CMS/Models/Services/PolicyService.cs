﻿using CMS.Models.Services;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CMS.Models.Services
{
    public class PolicyService : BaseService
    {
       
        public PolicyService(IHttpClientFactory httpClientFactory)
        {
            this.client = httpClientFactory.CreateClient("policy");
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        // Working on this
        public async Task<List<Policy>> GetAllPolicy()
        {
            List<Policy> requests = new List<Policy>();
            var Response = await client.GetAsync("api/Policies/GetAllPolicy");
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            requests = JsonConvert.DeserializeObject<List<Policy>>(Json);
            return requests;
        }

        public async Task<Policy> GetPolicyById(string policyId)
        {
            Policy requests = new Policy();
            var Response = await client.GetAsync("api/Policies/GetPolicyByPolicyId/" + policyId);
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            requests = JsonConvert.DeserializeObject<Policy>(Json);
            return requests;
        }
    }
}
