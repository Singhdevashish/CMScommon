﻿using Claim.Api.Data;
using Claim.Api.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;

namespace Claim.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentController : ControllerBase
    {
        private ClaimDbContext context;

        static List<Document> document = new List<Document>();//In-memory database

        public DocumentController(ClaimDbContext context)
        {
            this.context = context;
        }


        [HttpPost]
        public IActionResult CreateNew([FromForm] UploadDocument dto)
        {
            var extension = Path.GetExtension(dto.File.FileName);
            var filename = Guid.NewGuid().ToString().Replace("-", String.Empty) + extension;
            var path = AppDomain.CurrentDomain.BaseDirectory;

            var stream = new FileStream(path + filename, FileMode.CreateNew, FileAccess.Write);
            dto.File.CopyTo(stream);
            stream.Close();

            var doc = new Document
            {
                CreatedOn = DateTime.Now,
                Type = dto.FileType,
                FileName = filename,
            };
            document.Add(doc);  //saving in database
            
            return Ok();
        }

        [HttpGet]
        public IActionResult GetDocuments()
        {
            var dtos = new List<DocumentDetails>();
            foreach (var doc in document)
            {
                dtos.Add(new DocumentDetails
                {
                    Type = doc.Type,
                    CreatedOn = doc.CreatedOn,
                    FileName = doc.FileName
                });
            }
            return Ok(dtos);
        }

        [HttpGet("{fileName}")]
        public IActionResult GetDocument(string fileName)
        {
            var path = AppDomain.CurrentDomain.BaseDirectory;

            var stream = new FileStream(path + fileName, FileMode.Open, FileAccess.Read);
            return File(stream, "application/octet-stream");
        }

        
    }
}
