﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Claim.Api.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Claims",
                columns: table => new
                {
                    ClaimId = table.Column<string>(nullable: false),
                    MemberId = table.Column<string>(nullable: false),
                    PolicyId = table.Column<string>(nullable: false),
                    ClaimAmount = table.Column<double>(nullable: false),
                    ClaimStatus = table.Column<string>(nullable: false),
                    FileName = table.Column<string>(nullable: false),
                    DateOfRaise = table.Column<DateTime>(nullable: false),
                    DateOfRequired = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Claims", x => x.ClaimId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Claims");
        }
    }
}
