﻿using Microsoft.AspNetCore.Http;
using System;

namespace Claim.Api.Models
{
    public class ClaimRequest
    {
        public string ClaimId { get; set; }

        public string MemberId { get; set; }

        public string PolicyId { get; set; }

        public double ClaimAmount { get; set; }

        public string ClaimStatus { get; set; }

        public string FileName { get; set; }

        public DateTime DateOfRaise { get; set; }

        public DateTime DateOfRequired { get; set; }
    }
}
