﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Claim.Api.Models
{
    public class Document
    {

        public string Type { get; set; }

        public DateTime CreatedOn { get; set; }

        public string FileName { get; set; }

    }
}
