﻿using Claim.Api.Models;
using Claim.Api.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;
using Claim.Api.Data;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System;
using Claim.Api.Models.DTOs;

namespace Claim.Api.Repository
{
    public class ClaimService : IClaimService
    {
        private readonly ClaimDbContext _claimDbContext;

        public ClaimService(ClaimDbContext claimDbContext)
        {
            _claimDbContext = claimDbContext;
        }

        public async Task<ResponseModel> CreateClaimRequest (ClaimDtos dto)
        {
            ResponseModel responseModel = new ResponseModel();

            try
            {
                dto.ClaimId = "CLAIMID" + new Random().Next(100000, 900000).ToString();
                await _claimDbContext.Claims.AddAsync(dto);
                await _claimDbContext.SaveChangesAsync();
                responseModel.IsSuccess = true;
                responseModel.Message = "Claim Requested Successfully";
            }
            catch (System.Exception e)
            {
                responseModel.IsSuccess = false;
                responseModel.Message = $"Error Occured {e.Message}";
            }

            return responseModel;
        }

        public async Task<List<ClaimDtos>> GetAllClaimRequests()
        {
            List<ClaimDtos> claimRequests;

            try
            {
                claimRequests = await _claimDbContext.Claims.Where(claimRequest => claimRequest.ClaimStatus == "INPROCESS").ToListAsync();
            }
            catch (System.Exception e)
            {
                System.Console.WriteLine(e.Message);
                return null;
            }

            return claimRequests;
        }

        public async Task<List<ClaimDtos>> GetAllProccessedClaimedRequests()
        {
            List<ClaimDtos> processedClaimRequests;

            try
            {
                processedClaimRequests = await _claimDbContext.Claims.Where(claimRequest => claimRequest.ClaimStatus != "INPROCESS").ToListAsync();
            }
            catch (System.Exception e)
            {
                System.Console.WriteLine(e.Message);
                return null;
            }

            return processedClaimRequests;
        }

        public async Task<List<ClaimDtos>> GetClaimsRequestedByMember(string memberId)
        {
            List<ClaimDtos> claimRequestsByMember;

            try
            {
                claimRequestsByMember = await _claimDbContext.Claims.Where(claimRequest => claimRequest.MemberId == memberId).ToListAsync();
            }
            catch (System.Exception e)
            {
                System.Console.WriteLine(e.Message);
                return null;
            }

            return claimRequestsByMember;
        }

        public async Task<List<ClaimDtos>> GetProccessedClaimRequestsOfMember(string memberId)
        {
            List<ClaimDtos> processedClaimRequestsByMember;

            try
            {
                processedClaimRequestsByMember = await _claimDbContext.Claims.Where(claimRequest => claimRequest.MemberId == memberId).ToListAsync();
            }
            catch (System.Exception e)
            {
                System.Console.WriteLine(e.Message);
                return null;
            }

            return processedClaimRequestsByMember;
        }

        public async Task<ResponseModel> EditClaimRequest(ClaimDtos claimRequest)
        {
            ResponseModel responseModel = new ResponseModel();

            try
            {
                _claimDbContext.Claims.Update(claimRequest);
                await _claimDbContext.SaveChangesAsync();
                responseModel.IsSuccess = true;
                responseModel.Message = "Claim Request Updated";
            }
            catch (System.Exception e)
            {
                responseModel.IsSuccess = false;
                responseModel.Message = $"Error Occured {e.Message}";
            }

            return responseModel;
        }

        public async Task<List<ClaimDtos>> GetClaimsRequestedByClaimId(string claimId)
        {
            List<ClaimDtos> claimRequestsByClaim;

            try
            {
                claimRequestsByClaim = await _claimDbContext.Claims.Where(claimRequest => claimRequest.ClaimId == claimId).ToListAsync();
            }
            catch (System.Exception e)
            {
                System.Console.WriteLine(e.Message);
                return null;
            }

            return claimRequestsByClaim;
        }

        public async Task<ResponseModel> Approve(string claimId, string claimStatus)
        {
            ResponseModel model = new ResponseModel();

            try
            {
                var approved =  _claimDbContext.Claims.FindAsync(claimId).Result;

                var claim = _claimDbContext.Claims.Where(c => c.ClaimId == approved.ClaimId).First();
                if (claim == null)
                {
                    model.IsSuccess = false;
                    model.Message = "Data not Found";
                    return model;
                }

                claim.ClaimStatus = claimStatus;

                await _claimDbContext.SaveChangesAsync();

                model.IsSuccess = true;
                model.Message = "Data Found";

                return model;
            }
            catch (Exception e)
            {
                model.IsSuccess = false;
                model.Message = e.Message;

                return model;
            }
        }
    }
}
