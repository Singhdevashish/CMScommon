﻿using Claim.Api.Models;
using Claim.Api.Models.DTOs;
using Claim.Api.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Claim.Api.Repository
{
    public interface IClaimService
    {
        Task<ResponseModel> CreateClaimRequest(ClaimDtos dto);

        Task<List<ClaimDtos>> GetAllClaimRequests();

        Task<List<ClaimDtos>> GetAllProccessedClaimedRequests();

        Task<List<ClaimDtos>> GetClaimsRequestedByMember(string memberId);

        Task<List<ClaimDtos>> GetClaimsRequestedByClaimId(string claimId);

        Task<List<ClaimDtos>> GetProccessedClaimRequestsOfMember(string memberId);
        
        Task<ResponseModel> EditClaimRequest(ClaimDtos claimRequest);

        Task<ResponseModel> Approve(string claimId, string claimStatus);
    }
}
