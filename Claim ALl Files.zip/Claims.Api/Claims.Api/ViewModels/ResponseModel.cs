﻿namespace Claim.Api.ViewModels
{
    public class ResponseModel
    {
        public bool IsSuccess { get; set; }

        public string Message { get; set; }
    }
}
