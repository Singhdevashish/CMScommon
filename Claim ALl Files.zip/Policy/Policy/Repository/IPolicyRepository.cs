﻿using Policy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Policy.Repository
{
    public interface IPolicyRepository
    {

        public List<ProviderPolicy> GiveAllProviderDetail();

        public double GivePolicyAmount(string policyId);

        public List<HealthPolicy> GiveListOfAllPolicy();

        public List<MemberPolicy> GiveAllMemberPolicy();

        public string ReceivePolicyId(string memberId);

        public List<HealthPolicy> GetPolicyByPolicyId(string policyId);


    }
}
