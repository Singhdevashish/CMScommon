﻿using Claim.Api.Models;
using Claim.Api.Models.DTOs;
using Claim.Api.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Claim.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class ClaimController : ControllerBase
    {
        private readonly IClaimService _claimService;
        private readonly log4net.ILog log;

        public ClaimController(IClaimService claimService)
        {
            _claimService = claimService;
            log = log4net.LogManager.GetLogger(typeof(ClaimController));
        }

        [HttpPost]
        public async Task<IActionResult> CreateClaimRequest([FromForm] ClaimRequest claimRequest)
        {
            try
            {
                var response = await _claimService.CreateClaimRequest(claimRequest);

                log.Info("CreateClaimRequest is Successful");

                if (response.Status == "SUCCESS")
                    return Ok(response);

                return BadRequest();
            }
            catch (System.Exception ex)
            {
                log.Info("CreateClaimRequest is UnSuccessful & Message :" + ex.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllClaimRequests()
        {
            try
            {
                var claimRequests = await _claimService.GetAllClaimRequests();

                log.Info("GetAllClaimRequests is Successful");

                if (claimRequests != null)
                    return Ok(claimRequests);

                return BadRequest("Claim requests not found");
            }
            catch (System.Exception ex)
            {
                log.Info("GetAllClaimRequests is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }

        }

        [HttpGet]
        public async Task<IActionResult> GetAllProccessedClaimedRequests()
        {
            try
            {
                var processedClaimRequests = await _claimService.GetAllProccessedClaimedRequests();

                log.Info("GetAllProccessedClaimedRequests is Successful");

                if (processedClaimRequests != null)
                    return Ok(processedClaimRequests);

                return BadRequest("Proccessed claim requests not found");
            }
            catch (System.Exception ex)
            {
                log.Info("GetAllProccessedClaimedRequests is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }
        }

        [HttpGet("{memberId}")]
        public async Task<IActionResult> GetClaimsRequestedByMember(string memberId)
        {
            try
            {
                var claimRequestsByMember = await _claimService.GetAllProccessedClaimedRequests();

                log.Info("GetClaimsRequestedByMember is Successful");

                if (claimRequestsByMember != null)
                    return Ok(claimRequestsByMember);

                return BadRequest($"Claim requests raised by member id {memberId} are not found");
            }
            catch (System.Exception ex)
            {
                log.Info("GetClaimsRequestedByMember is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }
        }

        [HttpGet("{memberId}")]
        public async Task<IActionResult> GetProccessedClaimRequestsOfMember(string memberId)
        {
            try
            {
                var proccessedClaimRequestsByMember = await _claimService.GetAllProccessedClaimedRequests();

                log.Info("GetProccessedClaimRequestsOfMember is Successful");

                if (proccessedClaimRequestsByMember != null)
                    return Ok(proccessedClaimRequestsByMember);

                return BadRequest($"Proccessed claim requests of member id {memberId} are not found");
            }
            catch (System.Exception ex)
            {
                log.Info("GetProccessedClaimRequestsOfMember is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }
        }

        [HttpGet("{claimId}")]
        public async Task<IActionResult> GetClaimRequested(string claimId)
        {
            try
            {
                var claim = await _claimService.GetClaimRequested(claimId);

                log.Info("GetClaimRequested is Successful");

                if (claim != null)
                    return Ok(claim);

                return BadRequest($"Claim requests of claim id {claimId} is not found");
            }
            catch (System.Exception ex)
            {
                log.Info("GetClaimRequested is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }
        }

        [HttpPatch("{claimId}/{claimStatus}")]
        public async Task<IActionResult> ApproveClaimRequest(string claimId, string claimStatus)
        {
            try
            {
                var response = await _claimService.ApproveClaimRequest(claimId, claimStatus);

                log.Info("ApproveClaimRequest is Successful");

                if (response.Status == "SUCCESS")
                    return Ok(response);

                return BadRequest();
            }
            catch (System.Exception ex)
            {
                log.Info("ApproveClaimRequest is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> EditClaimRequest([FromForm] ClaimRequest claimRequest)
        {
            try
            {
                var response = await _claimService.EditClaimRequest(claimRequest);
                log.Info("EditClaimRequest is Successful");


                if (response.Status == "SUCCESS")
                    return Ok(response);

                return BadRequest();
            }
            catch (System.Exception ex)
            {
                log.Info("EditClaimRequest is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }
        }

        // Documents

        [HttpGet]
        public IActionResult GetDocument(string fileName)
        {
            try
            {
                var documentStream = _claimService.GetDocument(fileName);

                log.Info("GetDocument is Successful");

                if (documentStream != null)
                    return File(documentStream, "application/pdf");

                return BadRequest($"Document {fileName} not found");
            }
            catch (System.Exception ex)
            {
                log.Info("GetDocument is UnSuccessful & Message :" + ex.Message);

                return BadRequest();
            }
        }
    }
}
