﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;


namespace Claim.Api.Models
{
    public class ClaimRequest
    {
        [Key]
        public string ClaimId { get; set; }

        [Required]
        public string MemberId { get; set; }

        [Required]
        public string PolicyId { get; set; }

        [Required]
        public double ClaimAmount { get; set; }

        [Required]
        public IFormFile Document { get; set; }

        [DefaultValue("INPROCESS")]
        public string ClaimStatus { get; set; }

        public string ClaimStatusDeniedReason { get; set; }
    }
}
