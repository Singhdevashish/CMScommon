﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Claim.Api.Models.DTOs
{
    public class ClaimDto
    {
        [Key]
        public string ClaimId { get; set; }

        public string MemberId { get; set; }

        public string PolicyId { get; set; }

        public double ClaimAmount { get; set; }

        public string FileName { get; set; }

        public string ClaimStatus { get; set; }

        public string ClaimStatusDeniedReason { get; set; }

        public DateTime RaisedDate { get; set; }

        public DateTime ApprovedDate { get; set; }
    }
}
