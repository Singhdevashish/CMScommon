﻿using Claim.Api.Data;
using Claim.Api.Models;
using Claim.Api.Models.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Claim.Api.Services
{
    public class ClaimService : IClaimService
    {
        private readonly ClaimDbContext _claimDbContext;
        private readonly log4net.ILog log;

        public ClaimService(ClaimDbContext claimDbContext)
        {
            _claimDbContext = claimDbContext;
            log = log4net.LogManager.GetLogger(typeof(ClaimService));
        }

        public async Task<Response> CreateClaimRequest(ClaimRequest claimRequest)
        {
            Response response = new Response();

            try
            {
                ClaimDto claimDto = new ClaimDto();

                // for text
                claimDto.ClaimId = "CLMID" + new Random().Next(100000000, 999999999).ToString();
                claimDto.RaisedDate = DateTime.Now;
                claimDto.ClaimStatus = claimRequest.ClaimStatus;

                // for docs
                var fileType = Path.GetExtension(claimRequest.Document.FileName);

                var documentName = claimDto.ClaimId + "_DOC" + new Random().Next(100000, 999999).ToString() + fileType;

                var documentPath = AppDomain.CurrentDomain.BaseDirectory;

                var documentStream = new FileStream(documentPath + documentName, FileMode.CreateNew, FileAccess.Write);

                claimRequest.Document.CopyTo(documentStream);
                documentStream.Close();

                claimDto.FileName = documentName;

                await _claimDbContext.Claims.AddAsync(claimDto);
                await _claimDbContext.SaveChangesAsync();

                log.Info("CreateClaimRequest is Successful");

                response.Status = "SUCCESS";
                response.Message = "Claim Requested Successfully";
            }
            catch (System.Exception ex)
            {
                log.Info("CreateClaimRequest is UnSuccessful & Message :" + ex.Message);

                response.Status = "ERROR";
                response.Message = $"Error Occured {ex.Message}";
            }

            return response;
        }

        public async Task<List<ClaimDto>> GetAllClaimRequests()
        {
            List<ClaimDto> claimRequests;

            try
            {
                claimRequests = await _claimDbContext.Claims.Where(claimRequest => claimRequest.ClaimStatus == "INPROCESS").ToListAsync();

                log.Info("GetAllClaimRequests is Successful");

            }
            catch (System.Exception ex)
            {
                log.Info("GetAllClaimRequests is UnSuccessful & Message :" + ex.Message);

                System.Console.WriteLine(ex.Message);
                return null;
            }

            return claimRequests;
        }

        public async Task<List<ClaimDto>> GetAllProccessedClaimedRequests() 
        {
            List<ClaimDto> processedClaimRequests;

            try
            {
                processedClaimRequests = await _claimDbContext.Claims.Where(claimRequest => claimRequest.ClaimStatus != "INPROCESS").ToListAsync();

                log.Info("GetAllProccessedClaimedRequests is Successful");

            }
            catch (System.Exception ex)
            {
                log.Info("GetAllProccessedClaimedRequests is UnSuccessful & Message :" + ex.Message);

                System.Console.WriteLine(ex.Message);
                return null;
            }

            return processedClaimRequests;
        }

        public async Task<List<ClaimDto>> GetClaimsRequestedByMember(string memberId)
        {
            List<ClaimDto> claimRequestsByMember;

            try
            {
                claimRequestsByMember = await _claimDbContext.Claims.Where(claimRequest => claimRequest.MemberId == memberId).ToListAsync();
                log.Info("GetClaimsRequestedByMember is Successful");

            }
            catch (System.Exception ex)
            {
                log.Info("GetClaimsRequestedByMember is UnSuccessful & Message :" + ex.Message);

                System.Console.WriteLine(ex.Message);
                return null;
            }

            return claimRequestsByMember;
        }

        public async Task<List<ClaimDto>> GetProccessedClaimRequestsOfMember(string memberId)
        {
            List<ClaimDto> proccessedClaimRequestsByMember;

            try
            {
                proccessedClaimRequestsByMember = await _claimDbContext.Claims.Where(claimRequest => claimRequest.MemberId == memberId).ToListAsync();
                log.Info("GetProccessedClaimRequestsOfMember is Successful");

            }
            catch (System.Exception ex)
            {
                log.Info("GetProccessedClaimRequestsOfMember is UnSuccessful & Message :" + ex.Message);

                System.Console.WriteLine(ex.Message);
                return null;
            }

            return proccessedClaimRequestsByMember;
        }

        public async Task<ClaimDto> GetClaimRequested(string claimId)
        {
            try
            {
                ClaimDto claim = await _claimDbContext.Claims.Where(claimRequest => claimRequest.ClaimId == claimId).FirstAsync();
                log.Info("GetClaimRequested is Successful");

                return claim;
            }
            catch (System.Exception ex)
            {
                log.Info("GetClaimRequested is UnSuccessful & Message :" + ex.Message);

                System.Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<Response> ApproveClaimRequest(string claimId, string claimStatus)
        {
            Response response = new Response();

            try
            {
                var claimRequest = _claimDbContext.Claims.FindAsync(claimId).Result;

                var claim = _claimDbContext.Claims.Where(c => c.ClaimId == claimRequest.ClaimId).First();


                if (claim == null)
                {
                    response.Status = "ERROR";
                    response.Message = "Claim not found";

                    return response;
                }

                claim.ClaimStatus = claimStatus;

                await _claimDbContext.SaveChangesAsync();

                log.Info("ApproveClaimRequest is Successful");

                response.Status = "SUCCESS";
                response.Message = "Claim request approved successfully";

                return response;
            }
            catch (Exception ex)
            {
                log.Info("ApproveClaimRequest is UnSuccessful & Message :" + ex.Message);

                response.Status = "ERROR";
                response.Message = ex.Message;

                return response;
            }
        }

        public async Task<Response> EditClaimRequest(ClaimRequest claimRequest)
        {
            Response response = new Response();

            try
            {
                ClaimDto claimDto = new ClaimDto();

                // for text
                claimDto.ClaimId = claimRequest.ClaimId;
                claimDto.RaisedDate = DateTime.Now;
                claimDto.ClaimStatus = claimRequest.ClaimStatus;

                // delete old docs
                var claimOldData = await _claimDbContext.Claims.FindAsync(claimRequest.ClaimId);
                File.Delete(claimOldData.FileName);

                // for docs
                var fileType = Path.GetExtension(claimRequest.Document.FileName);

                var documentName = claimDto.ClaimId + "_DOC" + new Random().Next(100000, 999999).ToString() + fileType;

                var documentPath = AppDomain.CurrentDomain.BaseDirectory;

                var documentStream = new FileStream(documentPath + documentName, FileMode.CreateNew, FileAccess.Write);

                claimRequest.Document.CopyTo(documentStream);
                documentStream.Close();

                claimDto.FileName = documentName;

                _claimDbContext.Claims.Update(claimDto);
                await _claimDbContext.SaveChangesAsync();

                log.Info("EditClaimRequest is Successful");

                response.Status = "SUCCESS";
                response.Message = "Claim requested updated successfully";
            }
            catch (System.Exception ex)
            {
                log.Info("EditClaimRequest is UnSuccessful & Message :" + ex.Message);

                response.Status = "ERROR";
                response.Message = ex.Message;
            }

            return response;
        }

        // Documents

        public FileStream GetDocument (string fileName)
        {
            try
            {
                var documentPath = AppDomain.CurrentDomain.BaseDirectory;

                var documentStream = new FileStream(documentPath + fileName, FileMode.Open, FileAccess.Read);

                log.Info("GetDocument is Successful");

                return documentStream;
            }
            catch (Exception ex)
            {
                log.Info("GetDocument is UnSuccessful & Message :" + ex.Message);

                return null;
            }
        }
    }
}
