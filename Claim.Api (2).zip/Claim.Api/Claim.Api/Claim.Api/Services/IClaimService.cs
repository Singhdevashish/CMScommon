﻿using Claim.Api.Models;
using Claim.Api.Models.DTOs;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Claim.Api.Services
{
    public interface IClaimService
    {
        Task<Response> CreateClaimRequest(ClaimRequest claimRequest);

        Task<List<ClaimDto>> GetAllClaimRequests();

        Task<List<ClaimDto>> GetAllProccessedClaimedRequests();

        Task<List<ClaimDto>> GetClaimsRequestedByMember(string memberId);

        Task<List<ClaimDto>> GetProccessedClaimRequestsOfMember(string memberId);

        Task<ClaimDto> GetClaimRequested(string claimId);

        Task<Response> ApproveClaimRequest(string claimId, string claimStatus);

        Task<Response> EditClaimRequest(ClaimRequest claimRequest);

        // Documents
        FileStream GetDocument(string fileName);
    }
}
