﻿namespace Auth.Api.Models
{
    public class ApproveRegistration
    {
        public string MemberId { get; set; }

        public string RegistrationStatus { get; set; }
    }
}
