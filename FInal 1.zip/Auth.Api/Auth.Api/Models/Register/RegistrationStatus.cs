﻿namespace Auth.Api.Models.Register
{
    public class RegistrationStatus
    {
        public const string INPROGRESS = "INPROGRESS";
        public const string ACCEPTED = "ACCEPTED";
        public const string DENIED = "DENIED";
    }
}
