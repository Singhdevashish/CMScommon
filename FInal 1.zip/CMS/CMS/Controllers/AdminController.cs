﻿using CMS.Models;
using CMS.Models.Services;
using CMS.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class AdminController : Controller
    {
        private readonly ClaimService claim;
        private readonly PolicyService policyService;
        private readonly UserService userService;
           
        public AdminController(ClaimService claim, PolicyService policyService, UserService userService)
        {
            this.claim = claim;
            this.policyService = policyService;
            this.userService = userService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> ClaimRequests()
        {
            List<ClaimRequest> claimRequest = await claim.GetAllClaimRequests();

            return View(claimRequest);
        }


        public async Task<IActionResult> Details(string claimId)
        {
            var claimDetail = await claim.GetClaimsRequestedByClaimId(claimId);
            if (claimDetail == null) return NotFound();

            var policy = await policyService.GetPolicyById(claimDetail.PolicyId);
            if (policy == null) return NotFound();

            if (policy.PolicyId == claimDetail.PolicyId)
            {
                ViewBag.PolicyId = policy.PolicyId;
                ViewBag.PolicyName = policy.PolicyName;
                ViewBag.PremiumAmount = policy.PremiumAmount;
                ViewBag.Tenure = policy.Tenure;
            }

            ViewBag.FileName = claimDetail.FileName;
            var member = await userService.GetMembersById(claimDetail.MemberId);
            if (member == null) return NotFound();

            ViewBag.MemberId = member.MemberId;
            ViewBag.Name = member.FirstName + " " + member.LastName;
            ViewBag.PhoneNumber = member.ContactNumber;
            ViewBag.Gender = member.Gender;

            return View(claimDetail);
        }

        [Route("{controller}/{action}")]
        public IActionResult Approve()
        {
            return View();
        }


        [Route("{controller}/{action}/{claimId}/{claimStatus}")]
        public async Task<IActionResult> Approve(string claimId, string claimStatus)
        {
            try
            {
                ClaimRequest claimRequest = new ClaimRequest();
                claimRequest.ClaimId = claimId;
                claimRequest.ClaimStatus = claimStatus;

                var response = await claim.Approve(claimId, claimStatus);

                if (response.IsSuccess == true)
                    return RedirectToAction("ClaimRequests");

                return BadRequest();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        public async Task<IActionResult> ProccessedClaim()
        {
            List<ClaimRequest> claimRequest = await claim.GetAllProccessedClaimedRequests();

            return View(claimRequest);
        }

    }
}