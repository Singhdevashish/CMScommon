﻿using CMS.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class DocumentController : Controller
    {
        private readonly HttpClient client;

        public DocumentController(IHttpClientFactory factory)
        {
            this.client = factory.CreateClient("claim");
        }
        public IActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Upload(UploadDocument model)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, "/api/document");
            using var content = new MultipartFormDataContent
            {
                { new StreamContent(model.File.OpenReadStream()), "File", model.File.FileName },
                { new StringContent(model.FileType), "FileType" },
            };
            request.Content = content;
            await client.SendAsync(request);


            return RedirectToAction("Create","Member");
        }

        public async Task<IActionResult> List()
        {
            var response = await client.GetAsync("/api/document");
            var content = await response.Content.ReadAsStringAsync();
            var data = JsonConvert.DeserializeObject<List<DocumentDetails>>(content);
            return View(data);
        }
    }
}
