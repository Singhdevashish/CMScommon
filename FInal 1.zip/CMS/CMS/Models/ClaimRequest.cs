﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class ClaimRequest
    {
        [Key]
        public string ClaimId { get; set; }

        [Required]
        public string MemberId { get; set; }

        [Required]
        public string PolicyId { get; set; }

        [Required]
        public double ClaimAmount { get; set; }

        [Required]
        [DefaultValue("INPROCESS")]
        public string ClaimStatus { get; set; }

        [Required]
        public string FileName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DateOfRaise { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DateOfRequired { get; set; }
    }
}
