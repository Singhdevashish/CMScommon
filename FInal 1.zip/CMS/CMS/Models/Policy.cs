﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class Policy
    {
        [Key]
        public string PolicyId { get; set; }

        [Required]
        public string PolicyName { get; set; }

        [Required]
        public int HospitalId { get; set; }

        [Required]
        public double PremiumAmount { get; set; }

        [Required]
        public int Tenure { get; set; }


    }
}
