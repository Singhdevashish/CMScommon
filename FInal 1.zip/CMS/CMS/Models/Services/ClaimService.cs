﻿using CMS.Models.Services;
using CMS.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Models.Services
{
    public class ClaimService : BaseService
    {
    
        public ClaimService(IHttpClientFactory httpClientFactory)
        {
            this.client = httpClientFactory.CreateClient("claim");
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<List<ClaimRequest>> GetAllClaimRequests()
        {
            List<ClaimRequest> requests = new List<ClaimRequest>();
            var Response = await client.GetAsync("api/Claim/GetAllClaimRequests");
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            requests = JsonConvert.DeserializeObject<List<ClaimRequest>>(Json);
            return requests;
        }

        public async Task<ClaimRequest> GetClaimsRequestedByClaimId(string claimId)
        {
            ClaimRequest details = new ClaimRequest();
            var Response = await client.GetAsync("api/Claim/GetClaimsRequestedByClaimId/" + claimId);
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            details = JsonConvert.DeserializeObject<ClaimRequest>(Json);
            return details;
        }

        public async Task<List<ClaimRequest>> GetAllProccessedClaimedRequests()
        {
            List<ClaimRequest> requests = new List<ClaimRequest>();
            var Response = await client.GetAsync("api/Claim/GetAllProccessedClaimedRequests");
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            requests = JsonConvert.DeserializeObject<List<ClaimRequest>>(Json);
            return requests;
        }

        public async Task<ClaimDetails> GetAllProccessedClaimedRequests(string id)
        {
            ClaimDetails details = new ClaimDetails();
            var Response = await client.GetAsync("api/Claim/GetAllProccessedClaimedRequests/" + id);
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            details = JsonConvert.DeserializeObject<ClaimDetails>(Json);
            return details;
        }

        // Working on this
        public async Task<bool> SaveClaim(ClaimRequest model)
        {
            var Json = JsonConvert.SerializeObject(model);
            var Content = new StringContent(Json, Encoding.UTF8, "application/json");

            var Response = await client.PostAsync("api/Claim/CreateClaimRequest/{model}", Content);
            Response.EnsureSuccessStatusCode();
            return Response.StatusCode == HttpStatusCode.Created;
        }


        public async Task<List<ClaimRequest>> GetClaimsRequestedByMember(string memberId)
        {
            List<ClaimRequest> details = new List<ClaimRequest>();
            var Response = await client.GetAsync("api/Claim/GetProccessedClaimRequestsOfMember/" + memberId);
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            details = JsonConvert.DeserializeObject<List<ClaimRequest>>(Json);
            return details;
        }

        /*public async Task<bool> GetUpdateClaimStatus(string claimStatus)
        {
            var Json = JsonConvert.SerializeObject(claimStatus);
            var Content = new StringContent(Json, Encoding.UTF8, "application/json");

            var Response = await client.PostAsync("/api/Claim/CreateClaimRequest", Content);
            Response.EnsureSuccessStatusCode();
            return Response.StatusCode == HttpStatusCode.Created;
        }*/


        public async Task<Response> Approve(string claimId, string claimStatus)
        {
            try
            {

                HttpContent httpContent = new StringContent("", Encoding.UTF8, "application/json");

                HttpResponseMessage httpResponseMessage = await client.PostAsync($"api/Claim/Approve/{claimId}/{claimStatus}", httpContent);

                var content = httpResponseMessage.Content.ReadAsStringAsync().Result;

                var response = JsonConvert.DeserializeObject<Response>(content);

                return response;

            }
            catch (Exception e)
            {
                Response response = new Response();
                response.IsSuccess = false;
                response.Message = e.Message;

                return response;
            }
        }

        public async Task<bool> UpdateClaimRequest(ClaimRequest model)
        {
            var Json = JsonConvert.SerializeObject(model);
            var Content = new StringContent(Json, Encoding.UTF8, "application/json");

            var Response = await client.PutAsync("api/Claim/EditClaimRequest/{model}", Content);
            Response.EnsureSuccessStatusCode();
            return Response.StatusCode == HttpStatusCode.OK;
        }

    }
}
