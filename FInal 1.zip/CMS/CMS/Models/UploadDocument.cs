﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Models
{
    public class UploadDocument
    {
        [Required]
        public string FileType { get; set; }

        [Required]
        public IFormFile File { get; set; }
    }
}
