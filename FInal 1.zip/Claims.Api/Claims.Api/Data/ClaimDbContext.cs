﻿using Claim.Api.Models.DTOs;
using Microsoft.EntityFrameworkCore;

namespace Claim.Api.Data
{
    public class ClaimDbContext : DbContext
    {

        public ClaimDbContext(DbContextOptions<ClaimDbContext> options) : base(options) { }

        public virtual DbSet<ClaimDtos> Claims { get; set; }

        
    }
}
