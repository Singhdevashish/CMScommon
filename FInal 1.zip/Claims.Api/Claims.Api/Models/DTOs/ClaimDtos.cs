﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Claim.Api.Models.DTOs
{
    public class ClaimDtos
    {
        [Key]
        public string ClaimId { get; set; }

        [Required]
        public string MemberId { get; set; }

        [Required]
        public string PolicyId { get; set; }

        [Required]
        public double ClaimAmount { get; set; }

        [Required]
        [DefaultValue("INPROCESS")]
        public string ClaimStatus { get; set; }

        [Required]
        public string FileName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DateOfRaise { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DateOfRequired { get; set; }
    }
}
