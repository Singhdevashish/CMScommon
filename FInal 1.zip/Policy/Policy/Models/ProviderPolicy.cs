﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Policy.Models
{
    public class ProviderPolicy
    {
        public int HospitalId { get; set; }

        public string HospitalName { get; set; }

        public string Location { get; set; } 
    }
}
