﻿using NUnit.Framework;

namespace PolicyTests
{
    [TestFixture]
    public class PoliciesControllerShould
    {
        
        [SetUp]
        public void Setup()
        {
           
        }

        /*[TestCase(1,1)]
        public void Check_GetEligibleBenefits_Is_Valid(int policyId, int memberId)
        {

          *//*  List<int> actual = .GetEligibleBenefits(policyId,memberId);
            int result = 3;
            Assert.AreEqual(result, actual.Count);*//*
        }*/
    }
}
