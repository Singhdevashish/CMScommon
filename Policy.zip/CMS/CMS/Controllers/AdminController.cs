﻿using CMS.Models;
using CMS.Models.Services;
using CMS.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class AdminController : Controller
    {
        private readonly ClaimService claim;
        private readonly PolicyService policyService;
        private readonly UserService userService;
        private readonly DocumentService documentService;
           
        public AdminController(ClaimService claim, PolicyService policyService, UserService userService, DocumentService documentService)
        {
            this.claim = claim;
            this.policyService = policyService;
            this.userService = userService;
            this.documentService = documentService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> ClaimRequests()
        {
            List<ClaimRequest> claimRequest = await claim.GetAllClaimRequests();

            return View(claimRequest);
        }


        public async Task<IActionResult> Details(string claimId)
        {
            var claimDetail = await claim.GetClaimsRequestedByClaimId(claimId);
            if (claimDetail == null) return NotFound();

            var policy = await policyService.GetPolicyById(claimDetail.PolicyId);
            if (policy == null) return NotFound();

            if (policy.PolicyId == claimDetail.PolicyId)
            {
                ViewBag.PolicyId = policy.PolicyId;
                ViewBag.PolicyName = policy.PolicyName;
                ViewBag.PremiumAmount = policy.PremiumAmount;
                ViewBag.Tenure = policy.Tenure;
            }

            //var doc = await documentService.GetDocument();
            
   
            return View(claimDetail);
        }

        public IActionResult Accept()
        {
            return View();
        }

        public IActionResult Denied()
        {
            return View();
        }

        public async Task<IActionResult> ProccessedClaim()
        {
            List<ClaimRequest> claimRequest = await claim.GetAllProccessedClaimedRequests();

            return View(claimRequest);
        }

    }
}