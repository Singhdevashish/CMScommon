﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Models.Services
{
    public class DocumentService
    {
        private HttpClient client;

        public DocumentService(IHttpClientFactory httpClientFactory)
        {
            this.client = httpClientFactory.CreateClient("claim");
            /*client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));*/
        }

        public async Task<bool> SaveDocument(UploadDocument model)
        {
            var Json = JsonConvert.SerializeObject(model);
            var Content = new StringContent(Json, Encoding.UTF8, "application/json");

            var Response = await client.PostAsync("/api/document/CreateNew", Content);
            Response.EnsureSuccessStatusCode();
            return Response.StatusCode == HttpStatusCode.Created;
        }

        public async Task<List<DocumentDetails>> GetDocument()
        {
            List<DocumentDetails> requests = new List<DocumentDetails>();
            var Response = await client.GetAsync("api/document/GetDocuments");
            Response.EnsureSuccessStatusCode();
            var Json = await Response.Content.ReadAsStringAsync();
            requests = JsonConvert.DeserializeObject<List<DocumentDetails>>(Json);
            return requests;
        }

    }
}
