﻿using CMS.Models;

namespace CMS.ViewModels
{
    public class ClaimDetails
    {
        public ClaimRequest ClaimRequest { get; set; }

        public Member Member { get; set; }

        public Policy Policy { get; set; }

        public Login Login { get; set; }

        public DocumentDetails DocumentDetails { get; set; }
    }
}
