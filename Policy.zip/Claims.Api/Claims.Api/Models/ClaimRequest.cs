﻿using Microsoft.AspNetCore.Http;

namespace Claim.Api.Models
{
    public class ClaimRequest
    {
        public string ClaimId { get; set; }

        public string MemberId { get; set; }

        public string PolicyId { get; set; }

        public float ClaimAmount { get; set; }

        public string ClaimStatus { get; set; }

        public string FileName { get; set; }
    }
}
