﻿using Claim.Api.Models;
using Claim.Api.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Claim.Api.Repository
{
    public interface IClaimService
    {
        Task<ResponseModel> CreateClaimRequest(Models.ClaimRequest claimRequest);

        Task<List<Models.ClaimRequest>> GetAllClaimRequests();

        Task<List<Models.ClaimRequest>> GetAllProccessedClaimedRequests();

        Task<List<Models.ClaimRequest>> GetClaimsRequestedByMember(string memberId);

        Task<List<Models.ClaimRequest>> GetClaimsRequestedByClaimId(string claimId);

        Task<List<Models.ClaimRequest>> GetProccessedClaimRequestsOfMember(string memberId);
        
        Task<ResponseModel> EditClaimRequest(Models.ClaimRequest claimRequest);
    }
}
