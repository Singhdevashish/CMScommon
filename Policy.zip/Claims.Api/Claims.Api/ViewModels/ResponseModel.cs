﻿namespace Claim.Api.ViewModels
{
    public class ResponseModel
    {
        public bool isSuccess { get; set; }

        public string Message { get; set; }
    }
}
